#include "piece_siam.h"

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int piece_etre_integre(const piece_siam* piece)
{

    assert(piece!=NULL);
    assert(type_etre_integre(piece->type));
    assert(orientation_etre_integre(piece->orientation));

    type_piece TestType = piece->type;
    orientation_deplacement TestOrientation = piece->orientation;
    int iReturn = 0;
    if(type_etre_animal(piece->type))
    {
       if(orientation_etre_integre_deplacement(piece->orientation))
            iReturn = 1;

    }

    else if(TestType>1 && TestType<4)
    {
        if(TestOrientation==aucune_orientation)
            iReturn = 1;

    }

    else
    {
        iReturn = 0;
    }

  return iReturn;
}

void piece_initialiser(piece_siam* piece)
{
    assert(piece!=NULL);

    piece_definir(piece,case_vide,aucune_orientation);

    assert(piece_etre_integre(piece));
}


int piece_etre_animal(const piece_siam* piece)
{
    /*
     * On vérifie si le pointeur pointe vers un emplacement mémoire viable
     * Puis si la piece est integre à savoir que celle ci possède une orientation
     * et un type cohérent
     * La fonction permet de vérifier si une  piece est  un animal via son type
     * enum  = 1 ou 2 par verification avec la fonction type_etre_animal()
     */

    assert(piece!=NULL);
    assert(piece_etre_integre(piece));

     if (type_etre_animal(piece->type)==1 )
          return 1;
     else
         return 0;
}


int piece_etre_rocher(const piece_siam* piece)
{
    /*
     * Verifie que la piece est integre
     * Permet de vérifier si une case est un rocher
     */
    assert(piece!=NULL);
    assert(piece_etre_integre(piece));

    if ( piece->type == rocher )
         return 1;
    else
        return 0;
}


int piece_etre_case_vide(const piece_siam* piece)
{
    /*
     * Verifie l'intégrité de la piece
     * Permet de vérifier si une case est vide
     */

    assert(piece!=NULL);
    assert(piece_etre_integre(piece));

    if ( piece->type == case_vide )
         return 1;
    else
        return 0;
}






void piece_definir(piece_siam* piece,type_piece type,orientation_deplacement orientation)
{
    /*
     *Attribue à un une variable piece des données passé en parametres
     *ces données doivent etre de type piece et d'orientation cohérente
     */

    assert(piece!=NULL);
    assert(type_etre_integre(type));
    assert(orientation_etre_integre(orientation));


    if(type_etre_animal(type)==1 && orientation!=aucune_orientation)
    {
        piece->type=type;
        piece->orientation=orientation;
    }
    
    if((type==2||type==3) && orientation==aucune_orientation)
    {
        piece->type=type;
        piece->orientation=orientation;

    }
    assert(piece_etre_integre(piece));
}


void piece_definir_rocher(piece_siam* piece)
{
    assert(piece!=NULL);
    piece_definir(piece,rocher,aucune_orientation);
    assert(piece_etre_integre(piece));
}

void piece_definir_case_vide(piece_siam* piece)
{
    assert(piece!=NULL);
    piece_definir(piece,case_vide,aucune_orientation);
    assert(piece_etre_integre(piece));
}





orientation_deplacement piece_recuperer_orientation_animal(const piece_siam* piece)
{
    assert(piece!=NULL);
    assert(piece_etre_integre(piece));
    assert(piece_etre_animal(piece));

    return piece->orientation;
}


void piece_afficher(const piece_siam* piece)
{
    assert(piece!=NULL);

    printf("%s,%s",type_nommer(piece->type),orientation_nommer(piece->orientation));
}

void piece_afficher_nom_cours(const piece_siam* piece)
{
    assert(piece!=NULL);

    printf("%s",type_nommer_nom_cours(piece->type));
    if(piece_etre_animal(piece))
        printf("-%s",orientation_nommer_nom_cours(piece->orientation));
}


piece_siam piece_correspondre_nom_cours(const char* nom_cours)
{
    assert(nom_cours!=NULL);
    assert(strlen(nom_cours)==3);

    //Possibilites:
    //
    // - nom vaut "***" -> case vide
    // - nom vaut "RRR" -> rocher
    // - nom commence par "e-" ou "r-"
    //     Alors il s'agit d'un animal.
    //     -> Recuperer le 3eme caractere
    //     -> Le convertir dans l'orientation de l'animal.
    //  - Si aucun des cas precedent, alors affiche erreur.

    piece_siam piece;
    piece_initialiser(&piece);


    if(strncmp(nom_cours,"***",3)==0)
    {
        piece_definir_case_vide(&piece);
    }
    else if(strncmp(nom_cours,"RRR",3)==0)
    {
        piece_definir_rocher(&piece);
    }
    else if((nom_cours[0]=='e' || nom_cours[0]=='r') && nom_cours[1]=='-')
    {
        const type_piece type=type_correspondre_caractere_animal(nom_cours[0]);
        const orientation_deplacement orientation=orientation_correspondre_caractere(nom_cours[2]);

        piece_definir(&piece,type,orientation);
    }
    else
    {
        printf("Erreur fonction %s\n",__FUNCTION__);
        abort();
    }

    return piece;

}


//----------------------------------------------------------------Fonction Test----------------------------------------------------------------//

void test_piece_etre_integre()
{
    piece_siam TestPiece;

    int iBoucle1 = 0;
    int iBoucle2 = 0;

    for(iBoucle1 = 0;iBoucle1<2;iBoucle1++)
    {
        TestPiece.type = iBoucle1;

        for(iBoucle2 = 0; iBoucle2<4;iBoucle2++)
        {
            TestPiece.orientation = iBoucle2;
            if(piece_etre_integre(&TestPiece)!=1)
                printf("Animal : %s Orientation : %s KO\n",type_nommer(TestPiece.type),
                       orientation_nommer(TestPiece.orientation));
        }
    }

    TestPiece.orientation = 4;

    for(iBoucle1=2;iBoucle1<4;iBoucle1++)
    {
        TestPiece.type = iBoucle1;

           if(piece_etre_integre(&TestPiece)!=1)
               printf("Animal : %s Orientation : %s KO\n",type_nommer(TestPiece.type),
                      orientation_nommer(TestPiece.orientation));

    }
}


void test_piece_etre_animal()
{
    piece_siam typeAnimal;
    int iBoucle = 0;
    puts("Test piece_etre_animal");

    typeAnimal.type = rhinoceros;
    for(iBoucle = 0; iBoucle<2; iBoucle++)
    {
        typeAnimal.type = iBoucle;
        if(piece_etre_animal(&typeAnimal)!=1)
            printf("Animal : %s KO", type_nommer(typeAnimal.type));

    }

}


void test_piece_etre_rocher()
{
    piece_siam typeRocher;

    puts("Test piece_etre_rocher");

    typeRocher.type = rocher;
    typeRocher.orientation = aucune_orientation;
    if(piece_etre_rocher(&typeRocher) !=1)
        puts("Rocher : KO");
}

void test_piece_etre_case_vide()
{
    piece_siam typeCaseVide;

    puts("Test piece_etre_case_vide");

    typeCaseVide.type = case_vide;
    typeCaseVide.orientation = aucune_orientation;
    if(piece_etre_case_vide(&typeCaseVide) !=1)
        puts("Case Vide : KO");
}

void test_piece_definir()
{
    puts("Test piece_definir");
    piece_siam TestPiece;
    TestPiece.orientation = bas;
    TestPiece.type = rhinoceros;
    int iBoucle1 = 0;
    int iBoucle2 = 0;

    for(iBoucle1 = 0;iBoucle1<2;iBoucle1++)
    {

        for(iBoucle2 = 0; iBoucle2<4;iBoucle2++)
        {
            piece_definir(&TestPiece,iBoucle1,iBoucle2);

            if(piece_etre_integre(&TestPiece)!=1)
                printf("Combinaison Piece : %s Orientation : %s KO",type_nommer(TestPiece.type),
                        orientation_nommer(TestPiece.orientation));

        }
    }

    for(iBoucle1=2;iBoucle1<4;iBoucle1++)
    {
         piece_definir(&TestPiece,iBoucle1,4);

         if(piece_etre_integre(&TestPiece)!=1)
             printf("Combinaison Piece : %s Orientation : %s KO",type_nommer(TestPiece.type),
                     orientation_nommer(TestPiece.orientation));

    }

}
