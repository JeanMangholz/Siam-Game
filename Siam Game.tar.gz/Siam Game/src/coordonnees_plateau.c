
#include "coordonnees_plateau.h"

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

int coordonnees_etre_dans_plateau(int x,int y)
{
    if((x>=0 && x<NBR_CASES) && (y>=0 && y<NBR_CASES))
        return 1;
    return 0;
}

int coordonnees_etre_bordure_plateau(int x,int y)
{
    /*
     * cette fonction verifie que les coordonnées passées en parametre sont au bord du plateau
     * On verifie que les coordonnees X et Y sont valables
     * Si X et Y sont au bord du plateau on retourne 1 sinon 0
     */
    assert(coordonnees_etre_dans_plateau(x,y));


    int iReturn = 0;

    if(x>=0 && x<NBR_CASES)
    {
        if(y==0 || y == NBR_CASES-1)
            iReturn=1;
    }

    if(y>=0 && y<NBR_CASES)
    {
        if(x==0 || x == NBR_CASES-1)
            iReturn=1;
    }
    return iReturn;
}

void coordonnees_appliquer_deplacement(int* x,int* y,orientation_deplacement orientation)
{
    assert(x!=NULL);
    assert(y!=NULL);
    assert(orientation_etre_integre_deplacement(orientation));

    // Table de correspondance:
    //  haut   -> (x,y+1)
    //  bas    -> (x,y-1)
    //  gauche -> (x-1,y)
    //  droite -> (x+1,y)

    switch(orientation)
    {
    case haut:
        *y+=1;
        break;
    case bas:
        *y-=1;
        break;
    case gauche:
        *x-=1;
        break;
    case droite:
        *x+=1;
        break;
    default:
        printf("Probleme fonction %s\n",__FUNCTION__);
    }
}


//----------------------------------------------------------------Fonction Test----------------------------------------------------------------//

void test_coordonnees_etre_bordure_plateau()
{
    puts("Test coordonnes etre bordure plateau");
    int iBcl = 0;

    for(iBcl = 0;iBcl<NBR_CASES;iBcl++)
    {
        if(coordonnees_etre_bordure_plateau(iBcl,0)!=1)
        {
            printf("Coordonees X : %d Y:% d KO",iBcl,0);
        }
    }

    for(iBcl = 0;iBcl<NBR_CASES;iBcl++)
    {
        if(coordonnees_etre_bordure_plateau(0,iBcl)!=1)
        {
            printf("Coordonees X : %d Y:% d KO",0,iBcl);
        }
    }
}

