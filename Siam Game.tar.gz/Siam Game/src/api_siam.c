#include "api_siam.h"
#include "plateau_modification.h"
#include "joueur.h"
#include "poussee.h"
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

coup_jeu api_siam_tenter_introduire_nouvelle_piece_si_possible(jeu_siam* jeu,
                                                               int x,int y,
                                                               orientation_deplacement orientation)
{
    /*
     *
     * Permet de vérifier que le pointeur est non nul
     * que le jeu est integre
     * La variable coup est initialement initialisé à zeros
     *
     * Si la fonction plateau_modification_introduire_piece_etre_possible est validé (=1) alors on introduit une nouvelle piece et
     * coup valide vaut 1, et on change de joueur.
     * On retourne la variable coup
     *
     */
    assert(jeu!=NULL);
    assert(jeu_etre_integre(jeu));

    piece_siam PieceCaseVide;
    type_piece Piece;


    piece_initialiser(&PieceCaseVide);

    PieceCaseVide = jeu->plateau.piece[x][y];
    Piece = joueur_obtenir_animal(jeu->joueur);

    coup_jeu coup;
    coup_jeu_initialiser(&coup);


     if(plateau_modification_introduire_piece_etre_possible(&jeu->plateau,x,y,Piece,orientation)==1)
     {
         plateau_modification_introduire_piece(&jeu->plateau,x,y,Piece,orientation);
         coup.valide = 1;
         jeu_changer_joueur(jeu);
     }
    else{

        if (poussee_etre_valide(&jeu->plateau,x,y,orientation)==1)
        {
             if(coordonnees_etre_bordure_plateau(x,y)==1)
             {
                 if(plateau_denombrer_type(&jeu->plateau,Piece)<5)
                 {
                    if(plateau_modification_introduction_angle_etre_possible(x,y,orientation)==1)
                    {

                        poussee_realiser(&jeu->plateau,x,y,jeu_obtenir_type_animal_courant(jeu),orientation);
                        plateau_modification_introduire_piece(&jeu->plateau,x,y,Piece,orientation);
                        coup.valide = 1;
                        condition_victoire(jeu,&coup,x,y,orientation);
                        jeu_changer_joueur(jeu);
                    }
                    else if(plateau_modification_detection_pas_angle(x,y,orientation)==1)
                    {

                        poussee_realiser(&jeu->plateau,x,y,jeu_obtenir_type_animal_courant(jeu),orientation);
                        plateau_modification_introduire_piece(&jeu->plateau,x,y,Piece,orientation);
                        condition_victoire(jeu,&coup,x,y,orientation);
                        coup.valide = 1;
                        jeu_changer_joueur(jeu);
                    }
                }
             }
        }
     }

    return coup;
}



coup_jeu api_siam_tenter_deplacer_piece_si_possible(jeu_siam* jeu,
                                                    int x,int y,
                                                    orientation_deplacement deplacement,
                                                    orientation_deplacement orientation)
{
    /*
     *
     * Permet de vérifier que le pointeur est non nul
     * que le jeu est integre
     * La variable coup est initialement initialisé à zeros
     *
     * Si la fonction plateau_modification_deplacer_piece_etre_possible est validé (=1) alors on deplace la piece et
     * coup valide vaut 1, et on change de joueur.
     * On retourne la variable coup
     *
     */

    assert(jeu!=NULL);
    assert(jeu_etre_integre(jeu));

    coup_jeu coup;
    type_piece TypePiece;
    coup_jeu_initialiser(&coup);
    const piece_siam* piece;
    int xTest = x;
    int yTest = y;



            if(plateau_modification_deplacer_piece_etre_possible(&jeu->plateau,x,y,deplacement,orientation)==1)
            {

                if (jeu_verifier_type_piece_a_modifier(jeu,x,y)==1)
                {


                    plateau_modification_deplacer_piece(&jeu->plateau,x,y,deplacement,orientation);
                    coup.valide=1;
                    jeu_changer_joueur(jeu);
                }
            }
            else{

                coordonnees_appliquer_deplacement(&xTest,&yTest,deplacement);
                if(poussee_etre_valide(&jeu->plateau,xTest,yTest,orientation)==1)
                {
                    piece = plateau_obtenir_piece_info(&jeu->plateau,x,y);

                    if((jeu_verifier_type_piece_a_modifier(jeu,x,y)==1) && (orientation == piece->orientation))
                    {


                        TypePiece = jeu_obtenir_type_animal_courant(jeu);
                        poussee_realiser(&jeu->plateau,x,y,TypePiece,deplacement);
                        condition_victoire(jeu,&coup,xTest,yTest,orientation);
                        coup.valide=1;
                        jeu_changer_joueur(jeu);
                    }
                }
            }

    return coup;
}



coup_jeu api_siam_tenter_changer_orientation_piece_si_possible(jeu_siam* jeu,int x,int y,orientation_deplacement orientation)
{
    /*
     * Permet de vérifier que le pointeur est non nul
     * que les coordinnées x et y sont bien dans le jeu
     * que le jeu est integre
     * que l'orientation est integre
     * La variable coup est initialement initialisé à zeros
     * Si la piece à modifier est correcte et si l'orientation de la piece sur le plateau est possible alors on change l'orientation de la piece,
     * coup valide vaut 1, et on change de joueur.
     * On retourne la variable coup
     */

    assert(jeu!=NULL);
    assert(jeu_etre_integre(jeu));

    coup_jeu coup;

    coup_jeu_initialiser(&coup);

    if(orientation_etre_integre_deplacement(orientation)==1)
    {
        if(coordonnees_etre_dans_plateau(x,y)==1)
        {
                if (plateau_modification_changer_orientation_piece_etre_possible(&jeu->plateau,x,y,orientation)==1)
                {
                    if (jeu_verifier_type_piece_a_modifier(jeu,x,y)==1)
                    {
                        plateau_modification_changer_orientation_piece(&jeu->plateau,x,y,orientation);

                        coup.valide=1;
                        jeu_changer_joueur(jeu);
                    }
                }

        }
    }

    return coup;
}
