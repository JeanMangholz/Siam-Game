
#include "piece_siam.h"
#include "plateau_siam.h"
#include "jeu_siam.h"
#include "api_siam.h"
#include "mode_interactif.h"
#include "plateau_modification.h"
#include "poussee.h"
#include <stdio.h>

void test_lancement()
{
  test_type_etre_animal();
  test_orientation_etre_integre_deplacement();
  test_piece_etre_integre();
  test_piece_etre_rocher();
  test_piece_etre_case_vide();
  test_piece_definir();
  test_plateau_obtenir_piece();
  test_plateau_etre_integre();
  test_plateau_exister_piece();
  test_coordonnees_etre_bordure_plateau();
  Test_jeu_verifier_type_piece_a_modifier();
  Test_jeu_obtenir_type_animal_courant();
  //Test_plateau_modification_changer_orientation_piece_etre_possible();
  //Test_plateau_modification_changer_orientation_piece();
    // puis tous les autres tests a ajouter
    //  de maniere iterative ...
}



int main()
{
    test_lancement();
    jeu_siam Jeu;
    jeu_initialiser(&Jeu);

    mode_interactif_lancer();


    return 0;
}
