#include "poussee.h"
#include "plateau_modification.h"
#include "joueur.h"
#include <assert.h>
#include <stdlib.h>
// 



/*
* Verifie si il est possible de realiser une poussee qui debute
* aux coordonnees (x,y) dans l'orientation definie.
*
* Note: Les coordonnees (x,y) designent la premiere piece rencontree
* dans la poussee(et non pas les coordonnees de la piece a l'origine
* de la poussee).
*
*
*  Necessite:
*
*   - Un pointeur non NULL vers un plateau integre non modifiable.
*
*   - Deux coordonnees entieres (x,y) designant une piece non vide integre du plateau.
*
*   - Une orientation de poussee designant une direction integre.
*
*
*   Garantie:
*
*   - Un retour valant 1 si la poussee est possible.
*
*   - Un retour valant 0 sinon.
*
*/
int poussee_etre_valide(const plateau_siam* plateau, int x, int y, orientation_deplacement orientation)
{
   assert(plateau!=NULL);
   assert(plateau_etre_integre(plateau));
   const piece_siam* Piece = plateau_obtenir_piece_info(plateau,x,y);
   int iNbrRocher = 0;
   int iNbrAnimauxSensOK = 1;
   int iReturn = 0;
piece_afficher_nom_cours(Piece);
   if((plateau_exister_piece(plateau,x,y)==1) && (orientation_etre_integre_deplacement(orientation)==1) && (coordonnees_etre_dans_plateau(x,y)==1)&&(plateau_denombrer_type(plateau,Piece->type)<6) )
   {

           do
           {
               Piece = plateau_obtenir_piece_info(plateau,x,y);

               if(Piece->type==rocher)//Compte le nombre de rocher présent en face de la piece
               {
                   iNbrRocher++;
               }

              if(piece_etre_case_vide(Piece)!=1)
              {
                   if(Piece->orientation==orientation_inverser(orientation))
                   {
                       iNbrAnimauxSensOK--;
                   }
                   if(Piece->orientation==orientation)
                   {
                       iNbrAnimauxSensOK++;

                   }

                   if(iNbrAnimauxSensOK>=iNbrRocher && iNbrAnimauxSensOK>0)
                   {
                       iReturn = 1;

                   }
                   else
                   {
                       iReturn = 0;
                   }
               }
              else
              {
                  if(iNbrAnimauxSensOK>=iNbrRocher && iNbrAnimauxSensOK>0)
                  {
                      iReturn = 1;
                  }
                  else
                  {
                      iReturn = 0;
                  }

                  break;
              }

                 coordonnees_appliquer_deplacement(&x,&y,orientation);
           }while(coordonnees_etre_dans_plateau(x,y)==1);

   }
return iReturn;
}


void poussee_realiser(plateau_siam* plateau,int x,int y,type_piece type,orientation_deplacement orientation){
    assert(plateau!=NULL);
    assert(plateau_etre_integre(plateau));
    const piece_siam* PieceFin;
    int xPieceFinal = 0;
    int yPieceFinal = 0;
    int xPieceVictoire = 0;
    int yPieceVictoire = 0;
    int iPieceFin = -1;//Variable d'etat
    int iNbrPiece = 0;
    int iBcl = 0;
    orientation_deplacement orientationinverse = orientation_inverser(orientation);

    if(poussee_etre_valide(plateau,x,y,orientation)==1 && type_etre_animal(type)==1)
    {
        //Recherche de la piece en fin de ligne
        do
        {
            PieceFin = plateau_obtenir_piece_info(plateau,x,y);
            if(PieceFin->type==case_vide)
            {
                iPieceFin = 0;
                break;
            }
            else
            {
                iPieceFin = 1;
            }

            iNbrPiece++;
            coordonnees_appliquer_deplacement(&x,&y,orientation);

        }while(coordonnees_etre_dans_plateau(x,y)==1);

        //Deplacement

            switch(iPieceFin)
            {
                case 0:
                for(iBcl = 0; iBcl<iNbrPiece;iBcl++)
                {
                    xPieceFinal = x;
                    yPieceFinal = y ;

                    coordonnees_appliquer_deplacement(&x,&y,orientationinverse);
                    poussee_deplacer_piece(plateau,x,y,xPieceFinal,yPieceFinal);
                }
                    break;
                case 1:
                    /*if(piece_etre_rocher(PieceFin)==1)
                    {
                        xPieceVictoire = x;
                        yPieceVictoire = y;
                        coordonnees_appliquer_deplacement(&xPieceVictoire,&yPieceVictoire,orientationinverse);
                        coordonnees_appliquer_deplacement(&xPieceVictoire,&yPieceVictoire,orientationinverse);
                       // condition->victoire= 1;
                        //condition->joueur = joueur_obtenir_numero_a_partir_animal(PieceTestVictoire->type);
                    }*/
                    coordonnees_appliquer_deplacement(&x,&y,orientationinverse);

                    for(iBcl = 0; iBcl<iNbrPiece;iBcl++)
                    {
                        xPieceFinal = x;
                        yPieceFinal = y ;
                        coordonnees_appliquer_deplacement(&xPieceFinal,&yPieceFinal,orientation);
                        poussee_deplacer_piece(plateau,x,y,xPieceFinal,yPieceFinal);
                        coordonnees_appliquer_deplacement(&x,&y,orientationinverse);
                    }

                    break;
            default:
                printf("Erreur fonction %s\n",__FUNCTION__);
                abort();


            }

    }

}

void poussee_deplacer_piece(plateau_siam* plateau,int xDepart, int yDepart, int xFinal, int yFinal)
{
    assert(plateau!=NULL);
    assert(plateau_etre_integre(plateau));
    assert(coordonnees_etre_dans_plateau(xDepart,yDepart));
    piece_siam* piecedepart;
    piece_siam* piecefinal;
    piecedepart = plateau_obtenir_piece(plateau,xDepart,yDepart);


    if(coordonnees_etre_dans_plateau(xFinal,yFinal)!=1)
    {
        plateau_modification_introduire_piece_vide(plateau,xDepart,yDepart);
        piecefinal = plateau_obtenir_piece(plateau,xDepart,yDepart);
    }
    else
    {
        piecefinal = plateau_obtenir_piece(plateau,xFinal,yFinal);
        piecefinal->orientation = piecedepart->orientation;
        piecefinal->type = piecedepart->type;
        plateau_modification_introduire_piece_vide(plateau,xDepart,yDepart);

    }
    assert(piece_etre_integre(piecefinal)==1);
    assert(plateau_etre_integre(plateau)==1);

}
