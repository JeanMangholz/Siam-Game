

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>


#include "victoire_siam.h"
#include "plateau_siam.h"
#include "orientation_deplacement.h"
#include "joueur.h"
#include "coup_jeu.h"



void condition_victoire(jeu_siam *jeu,coup_jeu *coup,int x,int y,orientation_deplacement orientation)
{
    int iNbrRocher = NBR_ROCHERS;
    const piece_siam *PieceFin;
    orientation_deplacement orientationinverse;
    orientationinverse = aucune_orientation;
    int Ibcl = 0;

    orientationinverse = orientation_inverser(orientation);
    iNbrRocher = plateau_denombrer_type(&jeu->plateau,rocher);



    if(iNbrRocher<NBR_ROCHERS)
    {
        do{
            coordonnees_appliquer_deplacement(&x,&y,orientation);

         }while(coordonnees_etre_bordure_plateau(x,y)!=1) ;

        do
        {
            PieceFin = plateau_obtenir_piece_info(&jeu->plateau,x,y);
            Ibcl++;
            piece_afficher_nom_cours(PieceFin);
            if(piece_etre_animal(PieceFin)==1 && PieceFin->orientation==orientation)
            {

                coup->condition_victoire.joueur = joueur_obtenir_numero_a_partir_animal(PieceFin->type);
                coup->condition_victoire.victoire = 1;
                break;
            }

            coordonnees_appliquer_deplacement(&x,&y,orientationinverse);

        }while(coordonnees_etre_dans_plateau(x,y)==1);

    }

}

