#include "plateau_siam.h"
#include "entree_sortie.h"

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>



void plateau_initialiser(plateau_siam* plateau)
{
    // Initialise l'ensemble des cases du plateau a piece_vide
    // sauf les 3 cases du milieu avec un rocher (1,2), (2,2) et (3,2)
    //
    // L'etat de l'echiquier initial est le suivant:
    //
    // [4] *** | *** | *** | *** | *** |
    // [3] *** | *** | *** | *** | *** |
    // [2] *** | RRR | RRR | RRR | *** |
    // [1] *** | *** | *** | *** | *** |
    // [0] *** | *** | *** | *** | *** |
    //     [0]   [1]   [2]   [3]   [4]
    //


    int kx=0;
    for(kx=0 ; kx<NBR_CASES ; ++kx)
    {
        int ky=0;
        for(ky=0 ; ky<NBR_CASES ; ++ky)
        {
            piece_siam* piece=plateau_obtenir_piece(plateau,kx,ky);
            assert(piece!=NULL);

            if(ky==2 && (kx>=1 && kx<=3) )
                piece_definir_rocher(piece);
            else
               piece_definir_case_vide(piece);
        }
    }

    assert(plateau_etre_integre(plateau));
}

int plateau_etre_integre(const plateau_siam* plateau)
{
    /*
     * La Fonction vérifie l'intégrité du plateau pour ce faire
     * elle vérifie que le pointeur du plateau est assigné à un emplacement
     * mémoire.
     *
     * Par la suite elle vérifie sur tout le plateau qu'il y ait un nombre
     * cohérent de rocher(1<nbr<4) de rhinoceros (0=<nbr<6)
     * d'élephant (0=<nbr<6)
     */

   assert(plateau!=NULL);

   int iNBRRocher = 0;
   int iNBRElephant = 0;
   int iNBRRhinoceros = 0;
   int iReturn = 0;


    iNBRRocher = plateau_denombrer_type(plateau,rocher);
    iNBRElephant = plateau_denombrer_type(plateau,elephant);
    iNBRRhinoceros = plateau_denombrer_type(plateau,rhinoceros);

    if(iNBRElephant>=0 && iNBRElephant<=5)
    {
          if(iNBRRhinoceros>=0 && iNBRRhinoceros<=5)
          {
                if(iNBRRocher>=2 && iNBRRocher<4)
                {
                    iReturn = 1;

                }
          }
     }

    return iReturn;
}

piece_siam* plateau_obtenir_piece(plateau_siam* plateau,int x,int y)
{

    /*
     * La fonction vérifie que le pointeur soit initialiser au préalable
     * Qu'il pointe donc vers un emplacement mémoire valide
     * Que les coordonnnées X Y soient cohérente avec la taille du tableau 2
     * afin d'éviter une eventuelle erreure de ségmentation
     */

    assert(plateau!=NULL);
    assert(coordonnees_etre_dans_plateau(x,y));


    return &(plateau->piece[x][y]);
}

const piece_siam* plateau_obtenir_piece_info(const plateau_siam* plateau,int x,int y)
{
    /*
     * La fonction vérifie que le pointeur soit initialiser au préalable
     * Qu'il pointe donc vers un emplacement mémoire valide
     * Que les coordonnnées X Y soient cohérente avec la taille du tableau 2
     * afin d'éviter une eventuelle erreure de ségmentation
     * La pièce retourné est de type const elle ne pourra donc pas être modifier par la suite
     */

    assert(plateau!=NULL);
    assert(coordonnees_etre_dans_plateau(x,y));
    const piece_siam* piecereturn = &(plateau->piece[x][y]);

    return  piecereturn;
}



int plateau_denombrer_type(const plateau_siam* plateau,type_piece type)
{
    assert(plateau!=NULL);

    // Algorithme:
    //
    // Initialiser compteur <- 0
    // Pour toutes les cases du tableau
    //Si case courante est du type souhaite
    //Incremente compteur
    // Renvoie compteur

    int compteur=0;
    int kx=0;
    for(kx=0 ; kx<NBR_CASES ; ++kx)
    {
    int ky = 0;
    for(ky=0 ; ky<NBR_CASES ; ++ky)
    {
    const piece_siam* piece=
    plateau_obtenir_piece_info(plateau,kx,ky);
    assert(piece!=NULL);
    if(piece->type == type)
    compteur++;
    }
    }
    return compteur;
}

int plateau_exister_piece(const plateau_siam* plateau,int x,int y)
{
    /*
     * Cette fonction vérifie qu'il y a une piece sur le plateau aux coordonnée données
     * le pointeur est initialisé au préalable,
     * les coordonnnées X Y sont cohérentes avec la taille du tableau
     * Si une piece est présente sur le tableau alors on retourne 1, sinon
     */

    assert(plateau!=NULL);
    assert(coordonnees_etre_dans_plateau(x,y));

    const piece_siam* piece;
    int iReturn = 0;

    piece = plateau_obtenir_piece_info(plateau,x,y);

    if(piece->type!=case_vide)
    {
        iReturn = 1;
    }
    return iReturn;
}

void plateau_afficher(const plateau_siam* plateau)
{
    assert(plateau!=NULL);

    //utilisation d'une fonction generique d'affichage
    // le parametre stdout permet d'indiquer que l'affichage
    // est realise sur la ligne de commande par defaut.
    entree_sortie_ecrire_plateau_pointeur_fichier(stdout,plateau);

}




//----------------------------------------------------------------Fonction Test----------------------------------------------------------------//


void test_plateau_obtenir_piece()
{
    plateau_siam  plateau;
    piece_siam piece;
    piece_siam *pieceretourne;

    piece.orientation = haut;
    piece.type = elephant;
    plateau_initialiser(&plateau);
    puts("Test Plateau_obtenir_piece");


    plateau.piece[0][0] = piece;
    pieceretourne = plateau_obtenir_piece(&plateau,0,0);

    if(pieceretourne->orientation != piece.orientation)
    {
        if(pieceretourne->type != piece.type)
        {
            printf("Pièce aux coordonnées X:%d Y:%d KO\n",0,0);
            piece_afficher( &(plateau.piece[0][0]));
        }
    }


}

void test_plateau_etre_integre()
{
    puts("Test_plateau_etre_integre");
    plateau_siam Plateautest;
    const plateau_siam* pPlateau = &Plateautest;
    piece_siam PieceTestRhino;
    piece_siam PieceTestElephant;
    int iBcl = 0;

    piece_initialiser(&PieceTestRhino);
    piece_initialiser(&PieceTestElephant);
    piece_definir(&PieceTestRhino,rhinoceros,haut);
    piece_definir(&PieceTestElephant,elephant,haut);
    plateau_initialiser(&Plateautest);




    for(iBcl = 0;iBcl<NBR_CASES;iBcl++)
    {
        Plateautest.piece[iBcl][0] = PieceTestElephant;
        Plateautest.piece[iBcl][1] = PieceTestRhino;
    }

    if(plateau_etre_integre(pPlateau)!=1)
    {
     puts("Test plateau integre KO");
    }

}

void test_plateau_exister_piece()
{
    puts("Test_plateau_exister_piece");
    plateau_siam Plateautest;
    const plateau_siam* pPlateau = &Plateautest;
    piece_siam PieceTestRhino;
    piece_siam PieceTestElephant;

    piece_initialiser(&PieceTestRhino);
    piece_initialiser(&PieceTestElephant);
    piece_definir(&PieceTestRhino,rhinoceros,haut);
    piece_definir(&PieceTestElephant,elephant,haut);
    plateau_initialiser(&Plateautest);

    Plateautest.piece[0][0] = PieceTestElephant;
    Plateautest.piece[1][0] = PieceTestRhino;


    if(plateau_exister_piece(pPlateau,0,0)!=1)
    {
     puts("Test plateau exister piece X=0 Y=0 KO");

    }

    if(plateau_exister_piece(pPlateau,1,0)!=1)
    {
     puts("Test plateau exister piece X=1 Y=0 KO");
    }

    if(plateau_exister_piece(pPlateau,2,1)!=0)
    {
     puts("Test plateau exister piece X=2 Y=0 KO");
    }

}


