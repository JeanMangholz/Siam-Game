#include "plateau_modification.h"
#include "coordonnees_plateau.h"
#include "jeu_siam.h"
#include "poussee.h"
#include <assert.h>
#include <stdlib.h>
#include <stdio.h>



int plateau_modification_introduire_piece_etre_possible(const plateau_siam* plateau,
                                                        int x,int y,
                                                        type_piece type,
                                                        orientation_deplacement orientation)
{
   /*
    *
    * La fonction vérifie un plateau initialiser et integre
    * La fonction verifie que l'introduction d'une piece est possible
    * aux coordoonées (X,Y) par la verification des règles
    *
    */
    assert(plateau!=NULL);
    assert(plateau_etre_integre(plateau));
    int iReturn = 0;
    const piece_siam* PieceTest = plateau_obtenir_piece_info(plateau,x,y);

    if(coordonnees_etre_bordure_plateau(x,y)!=1)
    {
        iReturn = 0;
    }
    else
    {

        if(orientation_etre_integre_deplacement(orientation)==1)
        {
            if(type_etre_animal(type)==1)
            {
                if(plateau_denombrer_type(plateau,type)<5)
                {
                   if(piece_etre_case_vide(PieceTest))
                   {
                       iReturn = 1;
                   }

                }
            }
        }
    }
   return iReturn;
}

void plateau_modification_introduire_piece_vide(plateau_siam* plateau, int x,int y)
{
    /*
     * Verifie que le plateau est initialement initialisé et non nul
     *
     * on introduit une piece vide
     *
     */

    assert(plateau!=NULL);
    plateau->piece[x][y].orientation = aucune_orientation;
    plateau->piece[x][y].type = case_vide;
}

void plateau_modification_introduire_piece(plateau_siam* plateau,
                                           int x,int y,
                                           type_piece type,
                                           orientation_deplacement orientation)
{

    /*
     * Verifie que le plateau est initialement initialisé et non nul
     * que le plateau est intègre
     *
     * Si la fonction plateau_modification_introduire_piece_etre_possible() est validé (=1) et si l'orientation est integre
     * alors on introduit une nouvelle piece
     *
     * on verifie à la fin que le plateau modifie est integre et que la nouvelle piece  est integre
     *
     */

    assert(plateau!=NULL);

    if(plateau_modification_introduire_piece_etre_possible(plateau,x,y,type,orientation)==1)
    {
        if(orientation_etre_integre(orientation)==1)
        {
            plateau->piece[x][y].orientation = orientation;
            plateau->piece[x][y].type = type;
        }
    }
    assert(plateau_etre_integre(plateau));
    assert(piece_etre_integre(plateau_obtenir_piece_info(plateau,x,y)));
}


int plateau_modification_changer_orientation_piece_etre_possible(const plateau_siam* plateau,int x0,int y0,orientation_deplacement orientation)
{
    /*
     * La fonction permet de changer l'orientation d'une piece
     * Si le pointeur du plateau est != NULL
     * Si les coordonnees sont integre
     * Si l'orientation est possible haut bas droit gauche
     * Si la piece est de type animal et orientation différente de celle actuelle alors on retourne 1 sinon 0
     *
     */

    assert(plateau != NULL);
    assert(plateau_etre_integre(plateau));



    const piece_siam* piece;
    int iReturn = 0;

    piece = plateau_obtenir_piece_info(plateau,x0,y0);

    if(orientation!=piece->orientation)
    {
        if(coordonnees_etre_dans_plateau(x0,y0)==1)
        {
            if(orientation_etre_integre_deplacement(orientation)==1)
            {
                if(piece_etre_animal(piece)==1)
                {
                    iReturn = 1;
                }
             }
        }
     }
    return iReturn;
}



void plateau_modification_changer_orientation_piece(plateau_siam* plateau,int x0,int y0,orientation_deplacement orientation)
{
    /*
     * La fonction modifie l'orientation de la piece au coordonnees passées en paramètre
     * Si la modification est possible
     *
     */

    assert(plateau!=NULL);
    assert(plateau_etre_integre(plateau));

    piece_siam* piece;

    piece = plateau_obtenir_piece(plateau,x0,y0);
    piece_afficher_nom_cours(piece);

    if(orientation_etre_integre_deplacement(orientation)==1)
    {
        if(plateau_modification_changer_orientation_piece_etre_possible(plateau,x0,y0,orientation))
        {
            piece->orientation = orientation;
        }
    }
    assert(plateau_etre_integre(plateau));
    assert(piece_etre_integre(piece));
}


int plateau_modification_deplacer_piece_etre_possible(const plateau_siam* plateau,
                                                      int x0,int y0,
                                                      orientation_deplacement direction_deplacement,
                                                      orientation_deplacement orientation)
{
    /*
     * Verifie que le plateau est initialement initialisé et non nul
     * que le plateau est intègre
     *
     * Si les coordonnees de la piece sont dans le plateau, si l'orientation de la piece est intègre, si le changement d'orientation est possible
     * si l'orientation de deplacement est intègre alors on appelle la fonction coordonnees_appliquer_deplacement() pour
     * connaitre le deplacement voulu par l'utilisateur
     *
     * on traite le cas du deplacement en fonction de la poussee, de la case vide et de la sortie de la piece du plateau
     * Si c'est tout bon on retourne 1 sinon 0
     *
     */

    assert(plateau!=NULL);
    assert(plateau_etre_integre(plateau));

    int x_deplacement=x0;
    int y_deplacement=y0;
    int iReturn=0;

    const piece_siam* piece;


    if(coordonnees_etre_dans_plateau(x0,y0)==1)
    {
        if(orientation_etre_integre_deplacement(orientation)==1)
        {


              if(orientation_etre_integre_deplacement(direction_deplacement)==1)
              {
                      coordonnees_appliquer_deplacement(&x_deplacement,&y_deplacement,direction_deplacement);
                      if(coordonnees_etre_dans_plateau(x_deplacement,y_deplacement)!=1)
                      {
                          iReturn = 1;
                      }
                      else
                      {
                          piece = plateau_obtenir_piece_info(plateau,x_deplacement,y_deplacement);
                          if(piece_etre_case_vide(piece)==1)
                          {
                              iReturn = 1;
                          }
                          else
                          {
                              iReturn = 0;
                          }
                       }
               }

           }
      }

    return iReturn;
}



void plateau_modification_deplacer_piece(plateau_siam* plateau,
                                         int x0,int y0,
                                         orientation_deplacement direction_deplacement,
                                         orientation_deplacement orientation_final)
{
    /*
     * Verifie que le plateau est initialement initialisé et non nul
     * que le plateau est intègre
     *
     * Si la modification de la piece est possible alors on appelle la fonction coordonnees_appliquer_deplacement() pour
     * connaitre le deplacement voulu par l'utilisateur
     *
     * on traite le cas du deplacement en fonction de la poussee, de la case vide et de la sortie de la piece du plateau
     *
     * Verifie à la fin que le plateau est integre
     */

    assert(plateau!=NULL);
    assert(plateau_etre_integre(plateau));

    const piece_siam* piecetest;
    int x_deplacement=x0;
    int y_deplacement=y0;


    if(plateau_modification_deplacer_piece_etre_possible(plateau,x0,y0,direction_deplacement,orientation_final)==1)
    {
        coordonnees_appliquer_deplacement(&x_deplacement,&y_deplacement,direction_deplacement);
        if(coordonnees_etre_dans_plateau(x_deplacement,y_deplacement)!=1)
        {
            plateau_modification_introduire_piece_vide(plateau,x0,y0); // la piece sort du plateau

        }
        else
        {
            piecetest = plateau_obtenir_piece_info(plateau,x_deplacement,y_deplacement);
            if(piece_etre_case_vide(piecetest)==1) // si le deplacement se fait sur une case vide
            {
                plateau->piece[x_deplacement][y_deplacement].orientation = orientation_final;
                plateau->piece[x_deplacement][y_deplacement].type = plateau->piece[x0][y0].type;
                plateau_modification_introduire_piece_vide(plateau,x0,y0);
            }
         }
      }
    assert(plateau_etre_integre(plateau));
}
int plateau_modification_detection_zone(int x,int y)
{
    // [4] angle 2 | *** | *** | *** | Angle 3 |
    // [3] ***     | *** | *** | *** | ***     |
    // [2] ***     | RRR | RRR | RRR | ***     |
    // [1] ***     | *** | *** | *** | ***     |
    // [0] angle 1 | *** | *** | *** | Angle 4 |
    //       [0]     [1]   [2]   [3]     [4]

    int iReturn = 0;

   if(x==0 && (y<4 || y>0))//colonne1
   {
       iReturn = 1;
   }

   if(y==0 && (x<4 || x>0))//Ligne 1
   {
       iReturn = 2;
   }


   if(x==4 && (y<4 || y>0))//colonne 2
   {
       iReturn = 3;
   }

   if(y==4 && (x<4 || x>0))//ligne 2
   {
       iReturn = 4;
   }




    return iReturn;
}

int plateau_modification_detection_pas_angle(int x, int y, orientation_deplacement orientation)
{
    // [4] angle 2 | *** | *** | *** | Angle 3 |
    // [3] ***     | *** | *** | *** | ***     |
    // [2] ***     | RRR | RRR | RRR | ***     |
    // [1] ***     | *** | *** | *** | ***     |
    // [0] angle 1 | *** | *** | *** | Angle 4 |
    //       [0]     [1]   [2]   [3]     [4]

    int iReturn = 0;
    int iZone = 0;
    iZone = plateau_modification_detection_zone(x,y);
    switch(iZone)
    {
    case 1:
        if(orientation == droite)
        {
            iReturn = 1;
        }
        break;

    case 2:
        if(orientation == haut)
        {
            iReturn = 1;
        }
        break;

    case 3:
        if(orientation == gauche)
        {
            iReturn = 1;
        }
        break;

    case 4:
        if(orientation == bas)
        {
            iReturn = 1;
        }
        break;

    default:
        iReturn = 0;
    }




    return iReturn;
}

int plateau_modification_detection_angle(int x, int y)
{
    // [4] angle 2 | *** | *** | *** | Angle 3 |
    // [3] ***     | *** | *** | *** | ***     |
    // [2] ***     | RRR | RRR | RRR | ***     |
    // [1] ***     | *** | *** | *** | ***     |
    // [0] angle 1 | *** | *** | *** | Angle 4 |
    //       [0]     [1]   [2]   [3]     [4]

    int iReturn = 0;

    if(x==0 && y==0)
    {
        iReturn = 1;
    }

    if(x==0 && y==4)
    {
        iReturn = 2;
    }
    if(x==4 && y==4)
    {
        iReturn = 3;
    }
    if(x==4 && y==0)
    {
        iReturn = 4;
    }

    return iReturn;
}

int plateau_modification_introduction_angle_etre_possible(int x, int y,orientation_deplacement orientation)
{
    // [4] angle 2 | *** | *** | *** | Angle 3 |
    // [3] ***     | *** | *** | *** | ***     |
    // [2] ***     | RRR | RRR | RRR | ***     |
    // [1] ***     | *** | *** | *** | ***     |
    // [0] angle 1 | *** | *** | *** | Angle 4 |
    //       [0]     [1]   [2]   [3]     [4]
    int iReturn = 0;
    int angle = 0;
    angle = plateau_modification_detection_angle(x,y);
    switch(angle)
    {
    case 1:
        if(orientation==droite || orientation==haut)
        {
            iReturn = 1;
        }
        break;

    case 2:
        if(orientation==droite || orientation==bas)
        {
            iReturn = 1;
        }
        break;
    case 3:
        if(orientation==gauche || orientation==bas)
        {
            iReturn = 1;
        }
        break;
    case 4:
        if(orientation==gauche || orientation==haut)
        {
            iReturn = 1;
        }
        break;
    default:
        iReturn = 0;
    }

    return iReturn;
}

//----------------------------------------------------------------Fonction Test----------------------------------------------------------------//

void Test_plateau_modification_changer_orientation_piece_etre_possible()
{
    puts("Test plateau modification changer orientation piece etre possible\n");
    int iBcltype = 0;
    int iBclorientation = 0;
    plateau_siam plateau;
    const plateau_siam* pPlateau = &plateau;
    piece_siam* piece;
    plateau_initialiser(&plateau);



    piece = plateau_obtenir_piece(&plateau,0,0);

    piece->orientation = haut;

    for(iBcltype = 0; iBcltype<2 ; iBcltype++)
    {
      piece->type = iBcltype;

        for(iBclorientation = 1; iBclorientation<3;iBclorientation++)
        {
             if(plateau_modification_changer_orientation_piece_etre_possible(pPlateau,0,0,iBclorientation)!=1)
                printf("Test plateau modification changer orienation piece etre possible KO Etape : %d %d \n",iBclorientation,iBcltype);
        }
    }
}

void Test_plateau_modification_changer_orientation_piece()
{
    puts("Test plateau modification changer orientation piece");
    plateau_siam plateau;

    piece_siam piece;

    plateau_initialiser(&plateau);
    piece.orientation = haut;
    piece.type = elephant;
    plateau.piece[0][0] = piece;
    plateau_modification_changer_orientation_piece(&plateau,0,0,bas);
    piece = plateau.piece[0][0];
    if(piece.orientation!=bas)
       puts("Test plateau modification changer orientation piece  KO");

}



