#include "jeu_siam.h"
#include "joueur.h"

#include "entree_sortie.h"

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>


int jeu_etre_integre(const jeu_siam* jeu)
{
    assert(jeu!=NULL);

    //verification du joueur integre
    const int joueur=jeu->joueur;
    if(joueur_etre_integre(joueur)==0)
        return 0;

    //verification du plateau integre
    const plateau_siam* plateau=&jeu->plateau;
    if(plateau_etre_integre(plateau)==0)
        return 0;

    return 1;
}


void jeu_initialiser(jeu_siam* jeu)
{

    assert(jeu!=NULL);

    //initialise le plateau
    //initialise le joueur

    plateau_initialiser(&jeu->plateau);
    jeu->joueur=0;
}





void jeu_changer_joueur(jeu_siam* jeu)
{
    assert(jeu!=NULL);
    assert(jeu_etre_integre(jeu));

    joueur_changer(&jeu->joueur);

    assert(jeu_etre_integre(jeu));

}


int jeu_verifier_type_piece_a_modifier(const jeu_siam* jeu,int x,int y)
{

    /*
     * Cette fonction vérifie qu'on peut modifier la piece
     * Le pointeur est prealablement initialisé
     * Les coordonnées X et Y sont presents dans le plateau
     * le jeu est verifie pour qu'il soit bien integre
     * le type est verifie de telle façon à ce qu'il soit un animal
     * Si la piece est un elephant et le joueur est 0 alors on retourne 1
     * Si la piece est un rhinoceros et le joueur est 1 alors on retourne 1
     * sinon  0
     */

    assert(jeu!=NULL);
    assert(jeu_etre_integre(jeu));
    assert(coordonnees_etre_dans_plateau(x,y));

    const piece_siam* piece =  plateau_obtenir_piece_info(&jeu->plateau,x,y);

    int iReturn = 0;

    if(joueur_etre_type_animal(jeu->joueur,piece->type)==1)
        iReturn = 1;

    return iReturn;

}

void jeu_afficher(const jeu_siam* jeu)
{
    assert(jeu!=NULL);

    //utilisation d'une fonction generique avec affichage sur
    //  la ligne de commande.
    entree_sortie_ecrire_jeu_pointeur_fichier(stdout,jeu);
}



type_piece jeu_obtenir_type_animal_courant(const jeu_siam* jeu)
{


    assert(jeu!=NULL);
    assert(jeu_etre_integre(jeu));

    type_piece pieceReturn;

    switch(jeu->joueur)
    {
        case 0:
            pieceReturn = elephant;
            break;

        case 1:
            pieceReturn = rhinoceros;
            break;
     }

    return pieceReturn;
}

//----------------------------------------------------------------Fonction Test----------------------------------------------------------------//
void Test_jeu_verifier_type_piece_a_modifier()
{
    puts("Test jeu verifier type piece a modifier");

    jeu_siam JeuTest;
    const jeu_siam* pJeuTest = &JeuTest;
    piece_siam PieceTestRhino;
    piece_siam PieceTestElephant;

    piece_initialiser(&PieceTestRhino);
    piece_initialiser(&PieceTestElephant);
    piece_definir(&PieceTestRhino,rhinoceros,haut);
    piece_definir(&PieceTestElephant,elephant,haut);
    jeu_initialiser(&JeuTest);

    JeuTest.plateau.piece[0][0] = PieceTestElephant;

    if(jeu_verifier_type_piece_a_modifier(pJeuTest,0,0)!=1)
    {
        puts("Test jeu verifier type piece a modifier sur cas Joueur 0 KO");

    }

    JeuTest.plateau.piece[0][0] = PieceTestRhino;
    JeuTest.joueur = 1;

    if(jeu_verifier_type_piece_a_modifier(pJeuTest,0,0)!=1)
    {
        puts("Test jeu verifier type piece a modifier sur cas Joueur 1 KO");

    }
}

void Test_jeu_obtenir_type_animal_courant()
{
    puts("Test jeu verifier type animal courant");

    jeu_siam JeuTest;
    const jeu_siam* pJeuTest = &JeuTest;
    jeu_initialiser(&JeuTest);

    if(jeu_obtenir_type_animal_courant(pJeuTest)!=elephant)
    {
        puts("Test jeu verifier type animal courant sur cas Joueur 0 KO");

    }

    JeuTest.joueur = 1;

    if(jeu_obtenir_type_animal_courant(pJeuTest)!=rhinoceros)
    {
        puts("Test jeu verifier type animal courant sur cas Joueur 1 KO");

    }
}
