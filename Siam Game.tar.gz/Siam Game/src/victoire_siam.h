
/**
 * **************************************************
 * **************************************************
 *   _____ _____  ______   _
 *  / ____|  __ \|  ____| | |
 * | |    | |__) | |__    | |    _   _  ___  _ __
 * | |    |  ___/|  __|   | |   | | | |/ _ \| '_ \
 * | |____| |    | |____  | |___| |_| | (_) | | | |
 *  \_____|_|    |______| |______\__, |\___/|_| |_|
 *                                __/ |
 *                               |___/
 * **************************************************
 * **************************************************
 *
 * Role general de ce fichier
 * --------------------------------------------------------------
 * Un type_piece designe un type de case du jeu de siam.
 * Il peut etre du type elephant, rhinoceros, rocher, ou bien d'une case vide.
 * On separe les types qualifies d'animaux: elephant et rhinoceros des deux autres.
 *
 * Role des fonctions et note d'implementation
 * --------------------------------------------------------------
 * Les fonctions de ces fichiers ne s'occupent ici que de la manipulation des types,
 *   tels que leur affichages ou la verification qu'il s'agit bien d'un animal.
 * Un animal sera designe par une enumeration dans le programme. Lors du dialogue
 *   avec l'utilisateur, un animal sera cependant designe par un caractere ou
 *   une chaine de caractere reduite:
 *    - " e " pour un elephant 
 *    - " r " pour un rhinoceros
 *    - "RRR" pour un rocher,
 *    - "***" pour une case vide.
 * Les fonctions de conversions entre enumeration et caracteres sont egalement
 *   proposees dans ces fichiers.
 *
 * Notion d'abstraction
 * --------------------------------------------------------------
 * Il s'agit d'un niveau d'abstraction bas du jeu.
 * Dans le reste du programme, on utilisera les fonctions proposees ici
 *   pour manipuler les types de pieces. Il ne devra pas y avoir de manipulation
 *   directe (ex. type==elephant || type==rhinoceros) dans le reste du programme.
 *
 */

#include "jeu_siam.h"
#ifndef TYPE_PIECE_H
#define TYPE_PIECE_H

void condition_victoire(jeu_siam *jeu,int x,int y);



#endif
